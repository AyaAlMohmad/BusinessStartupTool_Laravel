<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <style>
        body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
        }

        .dashboard {
        width: 80%;
        margin: 20px auto;
        background-color: #fff;
        padding: 20px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .summary {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
        }

        .summary-item {
        width: 22%;
        padding: 15px;
        background-color: #f9f9f9;
        text-align: center;
        border: 1px solid #ddd;
        border-radius: 5px;
        }

        .details {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
        }

        .details > div {
        width: 48%;
        }

        table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 20px;
        }

        table, th, td {
        border: 1px solid #ddd;
        }

        th, td {
        padding: 10px;
        text-align: left;
        }

        h3 {
        margin-top: 0;
        }

        .status-item {
        width: 30%;
        text-align: center;
        background-color: #f9f9f9;
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 5px;
        }

        .funding-status {
        display: flex;
        justify-content: space-between;
        }

        </style>
        <div class="dashboard">
            <div class="summary">
                <div class="summary-item">
                    <h3>Total Startup Costs</h3>
                    <p>$4,000</p>
                    <span>Across all users</span>
                </div>
                <div class="summary-item">
                    <h3>Average Startup Cost</h3>
                    <p>$667</p>
                    <span>Per business</span>
                </div>
                <div class="summary-item">
                    <h3>Total Funding</h3>
                    <p>$47,473,783</p>
                    <span>All sources</span>
                </div>
                <div class="summary-item">
                    <h3>Avg. Breakeven</h3>
                    <p>0 months</p>
                    <span>Expected timeline</span>
                </div>
            </div>
            <div class="details">
                <div class="funding-distribution">
                    <h3>Funding Distribution</h3>
                    <table>
                        <tr>
                            <th>Source</th>
                            <th>Amount</th>
                            <th>%</th>
                        </tr>
                        <tr>
                            <td>Equity</td>
                            <td>$0</td>
                            <td>0%</td>
                        </tr>
                        <tr>
                            <td>Debt</td>
                            <td>$0</td>
                            <td>0%</td>
                        </tr>
                        <tr>
                            <td>Grant</td>
                            <td>$0</td>
                            <td>0%</td>
                        </tr>
                        <tr>
                            <td>Personal</td>
                            <td>$47,473,783</td>
                            <td>100%</td>
                        </tr>
                        <tr>
                            <td>Other</td>
                            <td>$0</td>
                            <td>0%</td>
                        </tr>
                    </table>
                </div>
                <div class="cost-categories">
                    <h3>Cost Categories</h3>
                    <table>
                        <tr>
                            <th>Category</th>
                            <th>Amount</th>
                            <th>%</th>
                        </tr>
                        <tr>
                            <td>Equipment</td>
                            <td>$0</td>
                            <td>0%</td>
                        </tr>
                        <tr>
                            <td>Inventory</td>
                            <td>$0</td>
                            <td>0%</td>
                        </tr>
                        <tr>
                            <td>Licenses</td>
                            <td>$0</td>
                            <td>0%</td>
                        </tr>
                        <tr>
                            <td>Marketing</td>
                            <td>$0</td>
                            <td>0%</td>
                        </tr>
                        <tr>
                            <td>Other</td>
                            <td>$4,000</td>
                            <td>100%</td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="funding-status">
                <h3>Funding Status Overview</h3>
                <div class="status-item">
                    <h4>Planned</h4>
                    <p>$0</p>
                    <span>0%</span>
                </div>
                <div class="status-item">
                    <h4>Secured</h4>
                    <p>$47,473,783</p>
                    <span>100%</span>
                </div>
                <div class="status-item">
                    <h4>Pending</h4>
                    <p>$0</p>
                    <span>0%</span>
                </div>
            </div>
        </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\business\resources\views/dashboard.blade.php ENDPATH**/ ?>