<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <!-- Bootstrap CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

     <!-- FontAwesome -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        .navbar {
            display: flex;
            justify-content: space-around;
            background-color: #444;
            padding: 10px 0;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
        }

        .navbar a:hover {
            background-color: #555;
        }

        .container {
    /* margin: 20px; */
    /* display: flex; */
    padding: 20px;
    justify-content: flex-end; 
    align-items: center;      
   
}



        .search-bar {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .search-bar input {
            padding: 10px;
            width: 80%;
            border: 1px solid #ddd;
        }

        .search-bar button {
            padding: 10px;
            background-color: #008cba;
            color: white;
            border: none;
            cursor: pointer;
        }

        .search-bar button:hover {
            background-color: #005f8a;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 16px;
            font-family: Arial, sans-serif;
            text-align: left;
        }

        thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
            font-weight: bold;
        }

        th,
        td {
            padding: 12px 15px;
            border: 1px solid #ddd;
        }

        tbody tr {
            border-bottom: 1px solid #ddd;
        }

        tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        tbody tr:hover {
            background-color: #f1f1f1;
            cursor: pointer;
        }

        a {
            text-decoration: none;
            color: #009879;
            font-weight: bold;
            margin-right: 10px;
        }

        a:hover {
            text-decoration: underline;
            color: #005f56;
        }

        button {
            background-color: #009879;
            color: #ffffff;
            border: none;
            padding: 8px 12px;
            font-size: 14px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #007961;
        }

        form {
            display: inline-block;
        }

        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-size: 14px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .modal .form-control {
            border-radius: 5px;
            box-shadow: none;
            border: 1px solid #ddd;
        }

        .modal .btn {
            border-radius: 5px;
        }
    </style>
    <div class="container">

        <div class="search-bar">
            <input type="text" placeholder="Search users..." />
            <button>Export Data</button>
        </div>

        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Registration Date</th>
                    <th>Last Login</th>
                    <th>Progress</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <span style="display: inline-block; padding: 5px 10px; border-radius: 15px; font-size: 14px; color: white; 
                                     background-color: <?php echo e($user->status === 'active' ? '#28a745' : '#dc3545'); ?>;">
                            <?php echo e(ucfirst($user->status)); ?>

                        </span>
                    </td>

                    <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
                    <td><?php echo e($user->last_login ? $user->last_login->format('d/m/Y') : 'Never'); ?></td>
                    <td>Welcome
                        <span style="display: inline-block; padding: 5px 10px; border-radius: 15px; font-size: 14px; color: white; 
                                     background-color: #007bff;">
                           <?php echo e($user->progress ?? '0'); ?>%
                        </span>
                    </td>

                    <td>
                        <!-- View Icon -->
                        <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" title="View">
                            <i class="fas fa-eye" style="color: #009879; font-size: 18px;"></i>
                        </a>

                        <!-- Edit Icon -->
                        <a href="#" class="btn btn-link" data-bs-toggle="modal"
                            data-bs-target="#editUserModal-<?php echo e($user->id); ?>">
                            <i class="fas fa-pen"></i>
                        </a>

                     
                        <!-- Change Status Icon -->
                        <form action="<?php echo e(route('admin.changeStatus', $user->id)); ?>" method="POST"
                            style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" title="Change Status"
                                style="background: none; border: none; cursor: pointer;" onclick="return confirm('Are you sure you want to change the status of this user?')">
                                <i class="fas fa-ban" style="color: #ff9800; font-size: 18px; margin-left: 8px;"></i>
                            </button>
                        </form>

                        <!-- Delete Icon -->
                        <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST"
                            style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" title="Delete"
                                style="background: none; border: none; cursor: pointer;" onclick="return confirm('Are you sure you want to delete this user?')">
                                <i class="fas fa-trash-alt"
                                    style="color: #ff4d4d; font-size: 18px; margin-left: 8px;"></i>
                            </button>
                        </form>
                    </td>

                </tr>
                <div class="modal fade" id="editUserModal-<?php echo e($user->id); ?>" tabindex="-1"
                    aria-labelledby="editUserModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="modal-header">
                                    <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>

                                <div class="modal-body">
                                    <!-- Name -->
                                    <div class="mb-3">
                                        <label for="name-<?php echo e($user->id); ?>" class="form-label">Name</label>
                                        <input type="text" class="form-control" id="name-<?php echo e($user->id); ?>"
                                            name="name" value="<?php echo e($user->name); ?>" required>
                                    </div>

                                    <!-- Email -->
                                    <div class="mb-3">
                                        <label for="email-<?php echo e($user->id); ?>" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email-<?php echo e($user->id); ?>"
                                            name="email" value="<?php echo e($user->email); ?>" required>
                                    </div>

                                    <!-- Status -->
                                    <div class="mb-3">
                                        <label for="status-<?php echo e($user->id); ?>" class="form-label">Status</label>
                                        <select class="form-select" id="status-<?php echo e($user->id); ?>" name="status"
                                            required>
                                            <option value="active" <?php echo e($user->status == 'active' ? 'selected' :
                                                ''); ?>>Active</option>
                                            <option value="inactive" <?php echo e($user->status == 'inactive' ? 'selected' :
                                                ''); ?>>InActive</option>
                                                 <option value="blocked" <?php echo e($user->status == 'blocked' ? 'selected' :
                                                ''); ?>>Blocked</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-success">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Add any additional JS functionality here if needed
        });
    </script>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\business\resources\views/admin/users/index.blade.php ENDPATH**/ ?>