<?php
namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\BusinessSetup;
use Illuminate\Http\Request;

class BusinessSetupController extends Controller
{
    public function index()
    {
        return response()->json(BusinessSetup::with(['licenses', 'locations', 'insurances'])->get(), 200);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'business_type' => 'required|string',
            'requirements' => 'required|array',
            'timeline' => 'required|string',
            'setup_costs' => 'required|numeric',
        ]);

        $businessSetup = BusinessSetup::create($data);
        return response()->json($businessSetup, 201);
    }

    public function show($id)
    {
        $businessSetup = BusinessSetup::with(['licenses', 'locations', 'insurances'])->findOrFail($id);
        return response()->json($businessSetup, 200);
    }

    public function update(Request $request, $id)
    {
        $data = $request->validate([
            'business_type' => 'required|string',
            'requirements' => 'required|array', 
            'timeline' => 'required|string',
            'setup_costs' => 'required|numeric',
        ]);

        $businessSetup = BusinessSetup::findOrFail($id);
        $businessSetup->update($data);
        return response()->json($businessSetup, 200);
    }

    public function destroy($id)
    {
        $businessSetup = BusinessSetup::findOrFail($id);
        $businessSetup->delete();
        return response()->json(null, 204);
    }
}